-- Script SQL para remover a tabela conversation_states
DROP TABLE IF EXISTS conversation_states; 